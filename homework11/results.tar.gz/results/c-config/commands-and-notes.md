# C execution notes

B guard observed `results/b-resume.log` ending ALL COMPLETE at 13:53:08Z;
no C cluster mutation preceded that observation. Local sandbox rejected
127.0.0.1 access; commands were rerun with reviewed network escalation.

Configuration saved before/after Helm. Command:
`/private/tmp/darwin-arm64/helm upgrade hw11 homework11/chart -n hw11 --reuse-values --set hpa.enabled=true --set hpa.minReplicas=2 --set hpa.maxReplicas=3`.
Enabling HPA removes replicas from chart and transiently reset Deployment to
1, then HPA restored2 at13:53:55; this transition is NOT the experiment's2→3.

Observer started with `caffeinate -i python3 homework11/experiments/observe_c.py --release hw11 --namespace hw11 --prometheus http://127.0.0.1:19090 --duration 2400 --output results/c-observer`.
Both load wrappers use `caffeinate -i`. Exact phase commands/start/end/returncode
are in `results/c-commands.jsonl`; observations retain raw argv/output.

First balanced high attempt (`c-balanced-high-1`) failed before generate:
large ConfigMap apply request exceeded3MiB. Four created client Pods could
not mount the missing ConfigMap; only these failed clients were deleted.
Logs/schedule/manifest retained. Successful C schedules shorten history to
CONTROL+four prefix words, retaining16 dialogue identifiers. launch_c.py uses
kubectl create instead of apply, avoiding duplication in last-applied
annotations; cluster.py itself is unchanged. This is a different workload
from B and results must not be directly compared as identical schedules.

Balanced successful command:
`python3 homework11/experiments/run_c_phase.py --name c-balanced-high-2 --rate 12 --duration 240`.
After natural scale-down2 and no running requests, reset server caches with
`kubectl -n hw11 rollout restart deployment/hw11-inference` and waited
`kubectl -n hw11 rollout status deployment/hw11-inference --timeout=180s`.
Sticky command:
`python3 homework11/experiments/run_c_phase.py --name c-sticky-hot-1 --rate 12 --duration 240 --policy sticky --skew`.
Rollout surge Pods during reset are separate from autoscaling transitions.

Actual chart warmup is5s (retained B override), not default20s. Node runtime
is docker27.2.0, kubelet1.31.0, arm64, LinuxKit6.10.14. cAdvisor exposes
pod cgroup series with namespace/pod/id/cpu labels and no container label;
old observer process CPU/RAM filter therefore yields empty series. Corrected
source and backfill_cadvisor.py select job=cadvisor, cpu=total for CPU,
namespace=hw11, pod=hw11-inference-.*, id=.*/pod[^/]+ for pod-level cgroups.
PromQL regex is fully anchored, excluding child container paths; parent and
child cgroups must not be summed together. CPU is aggregate pod CPU and RAM
is pod working set; for this one-api-container Pod it includes pod overhead.
Raw corrected range backfills are results/c-cadvisor-backfill.jsonl; each
record retains full query URL/time/body. Resource metrics API and HPA CPU
were available throughout and independently saved.

Recovery evidence is active rules returning inactive while rule health=ok;
not absence of an ALERTS series alone. Pod deletionTimestamp can be future
(grace deadline), so use first observation of deletion plus first subsequent
absence/currentReplicas=2 for scale-down timing, not that timestamp as start.
