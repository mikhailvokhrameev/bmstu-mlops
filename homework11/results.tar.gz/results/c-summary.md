# Реальный опыт C, 17 ноября 2026, UTC

Сбор завершён14:12:16Z. Сохранены активные values/manifests/HPA/resource
metrics/Pod UID и transitions/EndpointSlice обоих Service/events/rules/
Prometheus instant+range и raw клиентский NDJSON. Источники:
`c-config/`, `c-observer/evidence.jsonl`, `c-cadvisor-backfill.jsonl`,
`c-transitions.jsonl`, `c-phase-times.jsonl`, `c-commands.jsonl`.
Подробные условия/неуспешный старт/ограничения — `c-config/commands-and-notes.md`.

| Наблюдение | balanced12rps,240s | sticky skew12rps,240s |
|---|---|---|
| Успешные / попытки |2702/2880|1238/2880|
| Отказы |178(6.18%)|1642(57.01%)|
| TTFC p95 клиента |6.323s|6.462s|
| Lag p95 |.00290s|.00290s|
| Последняя отправка |13:59:32.491|14:08:13.415|
| Последний ответ |13:59:33.630|14:08:19.551|
| HPA desired3 впервые |13:56:42.602|14:04:41.657|
| Новый Pod создан |13:56:40Z,mztkf|14:04:41Z,qnpsl|
| Новый Pod Ready |13:56:48Z|14:04:49Z|
| HPA current3 впервые |13:56:57.611|14:04:58.623|
| HPA desired2 впервые |14:02:26.909|14:11:28.482|
| HPA current2 впервые |14:02:43.475|14:11:42.604|
| От последней отправки до desired2/current2 |174.4s/191.0s|195.1s/209.2s|
| От последнего ответа до desired2/current2 |173.3s/189.8s|188.9s/203.1s|

API timestamps создания и Ready дают8s прогрева каждой новой реплики.
HPA desired/current показаны временем первого наблюдения коллектора, а не
точным временем изменения. HPA lastScaleTime/Pod creation могут предшествовать
этому наблюдению. Scale-down превысил окно120s: HPA использует историю
рекомендаций, CPU усредняется по окну; добавляются sync и опрос. Во время
снижения нагрузки сохранён condition `ScaleDownStabilized`.

| Алерт/прогон | pending наблюдён | firing наблюдён | inactive recovery |
|---|---|---|---|
| TTFC balanced |13:55:47.352|13:56:18.807|13:58:27.999|
| Refusal balanced |13:55:52.101|13:56:23.734|13:56:57.876|
| TTFC sticky |14:04:32.169|14:05:03.699|14:09:16.980|
| Refusal sticky |14:04:26.758|14:04:56.504|14:09:12.302|

В balanced оба алерта восстановились ещё во время high подачи после появления
третьей реплики. В sticky firing сохранялся до завершения нагрузки, recovery
подтверждён rules inactive/health ok. Доля отказов в alert — скользящее окно1m,
поэтому она может превышать10%, хотя итоговая доля balanced за240s=6.18%.
Оба правила `for30s` и минимум20 наблюдений/мин; точные activeAt/queries/values
находятся в raw rules и transitions. Нет оборванных потоков или timeout в
обоих успешно завершённых C прогонах.

Горячая sticky реплика gn4hd получила все2880 попыток от четырёх клиентских
Pod; новая qnpsl и вторая старая cwpqv —0 наблюдавшихся ответов. Возможны
случайное одинаковое распределение affinity или SNAT; сами клиентские IP
не доказывают адрес, видимый kube-proxy. За14:05:30–14:08:00 CPU pod cgroup
(30точек/Pod) среднее:gn4hd=.9893cores,cwpqv=.003414,qnpsl=.003356.
При двух репликах средняя около.496cores/.250 request≈198%>target60%; даже
одна полностью занятая реплика способна вызвать scale-up. Новая реплика
остаётся почти без запросов при сохранении существующих ClientIP привязок.
Сводка и точный PromQL: `c-sticky-cpu-summary.json`.

CPU/RAM cAdvisor имеют runtime-specific pod-level cgroup labels без container.
Использован job=cadvisor,cpu=total для CPU и id regex pod-cgroup, исключающий
дочерние container cgroups. Старый работающий observer сохранил пустые CPU/RAM
по первоначальному фильтру; исправленные raw range backfill за полный опыт
сохранены отдельно. HPA resource metrics доступны независимо. Не суммировать
вместе исходные пустые и backfill данные или parent+child cgroups.

Это C workload с короткой явной историей CONTROL и16префиксами; сравнение
с B как с полностью одинаковой нагрузкой некорректно. Есть полный failed
phase c-balanced-high-1 (ConfigMap request-size limit, generate не запущен).
Нагрузка была запущена только после подтверждённого ALL COMPLETE B.
После C остаются2Ready server Pod, HPA включён; нагрузочные Pod завершены.
